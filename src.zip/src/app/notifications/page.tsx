// app/notifications/page.tsx
'use client'

import { Notification } from '@/components/notifications/Notification'

export default function NotificationsPage() {
  return (
    <div>
      <Notification />
    </div>
  )
}
