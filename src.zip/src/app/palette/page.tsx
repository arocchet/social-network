import ThemePalette from "@/components/theme-palette";

export default function PalettePage() {
    return (
        <div>
            <ThemePalette />
        </div>
    )
}