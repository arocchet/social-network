import { CommentSchema } from "./comment";

export * from "./comment"

export const CommentSchemas = {
    Create: CommentSchema,
}